<html>
  <header>
    <title>cavalls</title>
  </header>
  <body>
    <h1>cavalls</h1>
    <ol>
      <li>araps</li>
      <li>anglesos</li>
      <li>angloaraps</li>
      <li>hanoberianos</li>
      <li>frisons</li>
    </ol>
    <img src="http://www.molideserra.com/public/arab_horse_running.jpg"></img>
  </body>
</html>
